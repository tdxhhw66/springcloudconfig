import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit{

  ngOnInit() {

    this.initContent();
  }

  /**初始化  导航条伸缩控制 */
  initContent(){
    $("#navbar").click(function(){    //导航条按钮
      $(".stretch").toggleClass("app-aside-folded");    //添加伸缩属性
      $(this).toggleClass("app-aside-folded");
      $(this).toggleClass('active');
      $('#content').toggleClass('content-stretch');
    });

    // 打开子页签
    $(document).on('click', 'nav a', function (e) {
      var $this = $(e.target), $active;
      $this.is('a') || ($this = $this.closest('a'));

      $active = $this.parent().siblings( ".active" );
      $active && $active.toggleClass('active').find('> ul:visible').slideUp(200);

      ($this.parent().hasClass('active') && $this.next().slideUp(200)) || $this.next().slideDown(200);
      $this.parent().toggleClass('active');

      $this.next().is('ul') && e.preventDefault();

      setTimeout(function(){ $(document).trigger('updateNav'); }, 300);
    });


  }
}
