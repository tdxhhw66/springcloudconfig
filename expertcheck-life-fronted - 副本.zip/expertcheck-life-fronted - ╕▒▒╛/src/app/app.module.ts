
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LocationStrategy, HashLocationStrategy } from "@angular/common";


import { UrlUtil } from './utils/url.util';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { NavbarComponent } from './component/homepage/navbar/navbar.component';
import { ContentComponent } from './component/homepage/content/content.component';
import { MenuComponent } from './component/homepage/menu/menu.component';
import { PaginationComponent } from "src/app/component/pagination/pagination.component";

@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    ContentComponent,
    NavbarComponent,
    PaginationComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [
    UrlUtil,
    { provide: LocationStrategy, useClass: HashLocationStrategy }
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule { }
