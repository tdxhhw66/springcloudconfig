export class ResponseModel{
    /**
	 * 是否成功执行(是否有数据)
	 */
    private  responseType;

	/**
	 * 返回信息（成功信息或错误信息）
	 */
	private  responseMessage;

	/**
	 * 返回状态码
	 */
	private responseStatusCode;

	/**
	 * 返回结果数据
	 */
	private  responseBody;
}