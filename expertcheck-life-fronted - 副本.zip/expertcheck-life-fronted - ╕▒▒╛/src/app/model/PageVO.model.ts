/**分页模型 */
export class PageVO {
    constructor(){}
    public currentPage: number = 1;
    public totalPage: number = 0;
    public totalNumber: number = 0;
    public pageSize: number = 5;
    public resultList: any[];
}