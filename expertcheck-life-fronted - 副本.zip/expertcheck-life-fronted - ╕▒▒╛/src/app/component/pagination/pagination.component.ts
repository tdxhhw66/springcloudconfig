import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'pagination-component',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.css']
})
export class PaginationComponent implements OnInit {
   //分页通用组件
  @Input() pageVO:any;
  @Output() updatePageDatas:EventEmitter<any> = new EventEmitter();

  private isFirstPage:boolean;
  private isLastPage:boolean;
  private totalNumber:number;

  constructor() {
    this.isFirstPage = false;
    this.isLastPage = false;
   }

  ngOnInit() {
    this.pageVO = {currentPage:1,totalPage:0,totalNumber:0};
  }


  extractPageData() {
    if (this.pageVO.currentPage === 1) {
      this.isFirstPage = true;
    } else {
      this.isFirstPage = false;
    }

    if (this.pageVO.currentPage === this.pageVO.totalPage) {
      this.isLastPage = true;
    } else {
      this.isLastPage = false;
    }

    this.totalNumber = this.pageVO.totalPage;
    if(this.totalNumber){
      this.totalNumber = 1;
    }
  }

  evalPageNumber() {
    this.pageVO.currentPage = eval(this.pageVO.currentPage + "");
  }

  previousPage() {
    if (!$.isNumeric(this.pageVO.currentPage)) {
      return;
    }

    this.evalPageNumber();
    if (this.pageVO.currentPage <= 1 || this.pageVO.currentPage > this.pageVO.totalPage) {
      return;
    }

    this.pageVO.currentPage = this.pageVO.currentPage - 1;
    this.extractPageData();
    this.updatePageDatas.emit();
  }

  nextPage() {
    if (!$.isNumeric(this.pageVO.currentPage)) {
      return;
    }

    this.evalPageNumber();
    if (this.pageVO.currentPage <= 0 || this.pageVO.currentPage >= this.pageVO.totalPage) {
      return;
    }

    this.evalPageNumber();
    this.pageVO.currentPage = this.pageVO.currentPage + 1;
    this.extractPageData();
    this.updatePageDatas.emit();
  }

  jumpPage() {
    if (!$.isNumeric(this.pageVO.currentPage)) {
      return;
    }

    this.evalPageNumber();

    if (this.pageVO.currentPage <= 0) {
        this.pageVO.currentPage = 1;
        this.extractPageData();
        this.updatePageDatas.emit();
    }

    if(this.pageVO.currentPage > this.pageVO.totalPage){
      this.pageVO.currentPage = this.pageVO.totalPage;
      this.extractPageData();
      this.updatePageDatas.emit();
    }

    this.extractPageData();
    this.updatePageDatas.emit();
  }
}
