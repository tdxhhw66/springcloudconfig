import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  public menuTabList: any;

  constructor() { }

  ngOnInit() {
    this.menuTabList = [
      {
        "id": 1,
        "name": "保单列表",
        // "link": "/application-list",
        "tag": "parent",
        "class": "btn-info"
      },
      {
        "id": 1,
        "name": "个人中心",
        "tag": "parent",
        "class": "btn-info",
        "menuTabChilds": [
          {
            "id": 1,
            "name": "密码修改",
            "tag": "child",
            "class": "btn-info"
          },
          {
            "id": 1,
            "name": "任务管理",
            "tag": "child",
            "class": "btn-info"
          },
          {
            "id": 1,
            "name": "更换头像",
            "tag": "child",
            "class": "btn-info"
          }
        ]
      },
      {
        "id": 1,
        "name": "菜单管理",
        "tag": "parent",
        "class": "btn-info"
      }
    ]

  }



}
