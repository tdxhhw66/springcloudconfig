import * as $ from 'jquery';
import * as is from 'is';       //is.js  一个强大的微型检测库
