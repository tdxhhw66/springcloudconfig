#!/bin/sh

#
# Name Server
#
nohup sh mqnamesrv > ns.log 2>&1 &

#
# Service Addr
#
ADDR=`hostname -i`:9876

local_host="`hostname --fqdn`"
local_ip=`host $local_host 2>/dev/null | awk '{print $NF}'`
ADDR=$local_ip:9876

#
# Broker
#
nohup sh mqbroker -n ${ADDR} -c /var/local/alibaba-rocketmq/conf/2m-2s-async/broker-a.properties  > bk.log 2>&1 &

echo "Start Name Server and Broker Successfully, ${ADDR}"
